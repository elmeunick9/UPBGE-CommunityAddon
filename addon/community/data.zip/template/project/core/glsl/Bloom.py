from filter2D import Filter2D

class Bloom(Filter2D):
	"""
	Makes everything clear glow with its own light, everything!
	
	.. image:: ../Filter2DImages/NoPreview.jpg
	
	\\ 

	"""
	pass