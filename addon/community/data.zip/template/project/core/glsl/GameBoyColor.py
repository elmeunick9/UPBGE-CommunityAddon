from filter2D import Filter2D

class GameBoyColor(Filter2D):
	"""
	
	Like on the old ages.
	
	.. image:: ../Filter2DImages/GameBoyColor.jpg
	
	\\
	
	"""
	
	pass