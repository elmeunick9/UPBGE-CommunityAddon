on_scene_added = []
on_scene_removed = []
on_next_frame = []